const axios = require('axios');

     async function createLoan() {
       try {
         const response = await axios.post('https://loans.gosap.ru/loans', {
           userId: 'user123',
           bookIds: ['book456', 'book789']
         });
         console.log('Заказ создан:', response.data);
       } catch (err) {
         console.error('Ошибка:', err.response.data);
       }
     }

     createLoan();