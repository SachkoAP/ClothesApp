const express = require('express');
const cors = require('cors');
     const mysql = require('mysql2/promise');
     const app = express();
     app.use(cors());   
     app.use(express.json());

     const pool = mysql.createPool({
       host: 'localhost',
       user: 'users_user',
       password: 'UsersPass123!',
       database: 'library_users'
     });

     pool.execute(`
       CREATE TABLE IF NOT EXISTS users (
         id VARCHAR(50) PRIMARY KEY,
         name VARCHAR(100),
         email VARCHAR(100) UNIQUE,
         password VARCHAR(100)
       )
     `).then(() => console.log('Таблица users создана'));

     app.post('/users', async (req, res) => {
       const { userId, name, email, password } = req.body;
       try {
         await pool.execute(
           'INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)',
           [userId, name, email, password]
         );
         res.status(201).json({ id: userId, name, email });
       } catch (err) {
         res.status(400).json({ error: err.message });
       }
     });
// Маршрут для получения списка пользователей
app.get('/users', async (req, res) => {
  console.log('Received request to /users'); // Логируем получение запроса
  try {
    const [rows] = await pool.query('SELECT id, name, email FROM users');
    console.log('Users data from DB:', rows); // Логируем данные из базы
    res.status(200).json(rows.map(row => ({ userId: row.id, name: row.name, email: row.email })));
  } catch (err) {
    console.log('Error in /users:', err.message); // Логируем ошибку
    res.status(400).json({ error: err.message });
  }
});

// Маршрут для получения пользователя по ID
app.get('/users/:id', async (req, res) => {
  const { id } = req.params;
  console.log(`Received request to /users/${id}`); // Логируем запрос с ID
  try {
    const [rows] = await pool.query('SELECT id, name, email FROM users WHERE id = ?', [id]);
    console.log(`User data for ID ${id}:`, rows); // Логируем данные из базы
    if (rows.length === 0) {
      console.log(`User with ID ${id} not found`); // Логируем отсутствие пользователя
      return res.status(404).json({ error: 'Пользователь не найден' });
    }
    res.status(200).json(rows[0]);
  } catch (err) {
    console.log(`Error in /users/${id}:`, err.message); // Логируем ошибку
    res.status(400).json({ error: err.message });
  }
});

	app.listen(3001, '127.0.0.1', () => {
  console.log('User Service running on port 3001');
});
