const express = require('express');
const cors = require('cors');
     const mysql = require('mysql2/promise');
     const app = express();
     app.use(cors());
     app.use(express.json());

     const pool = mysql.createPool({
       host: 'localhost',
       user: 'books_user',
       password: 'BooksPass123!',
       database: 'library_books'
     });

     pool.execute(`
       CREATE TABLE IF NOT EXISTS books (
         bookId VARCHAR(50) PRIMARY KEY,
         title VARCHAR(100),
         author VARCHAR(100),
         available_copies INT
       )
     `).then(() => console.log('Таблица books создана'));

     app.post('/books', async (req, res) => {
       const { bookId, title, author, available_copies } = req.body;
       try {
         await pool.execute(
           'INSERT INTO books (bookId, title, author, available_copies) VALUES (?, ?, ?, ?)',
           [bookId, title, author, available_copies]
         );
         res.status(201).json({ bookId, title, author, available_copies });
       } catch (err) {
         res.status(400).json({ error: err.message });
       }
     });

     app.post('/books/availability', async (req, res) => {
       const { bookIds } = req.body;
       try {
         const [rows] = await pool.query(
           'SELECT bookId, title, available_copies FROM books WHERE bookId IN (?)',
           [bookIds]
         );
         const response = bookIds.map(id => {
           const book = rows.find(b => b.bookId === id);
           return {
             bookId: id,
             title: book ? book.title : '',
             available: book ? book.available_copies > 0 : false
           };
         });
         res.status(200).json({ books: response });
       } catch (err) {
         res.status(400).json({ error: err.message });
       }
     });
	app.get('/books', (req, res) => {
  	res.json([{ bookId: 'book123', title: 'Sample Book', available_copies: 5 }]);
	});
     app.listen(3002, '127.0.0.1', () => {
  	console.log('Book Service running on port 3002');
	});
