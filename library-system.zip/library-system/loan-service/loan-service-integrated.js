const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: 'localhost',
  user: 'loans_user',
  password: 'LoansPass123!',
  database: 'library_loans',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Инициализация таблицы
const initDatabase = async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS loans (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId VARCHAR(50),
        bookId VARCHAR(50),
        loanDate DATE,
        returnDate DATE
      )
    `);
    console.log('Таблица loans создана или уже существует');
  } catch (err) {
    console.error('Ошибка создания таблицы loans:', err.message);
    process.exit(1); // Завершаем процесс, если база недоступна
  }
};

// Вызываем инициализацию
initDatabase();

app.post('/loans', async (req, res) => {
  console.log('Received POST request to /loans:', req.body);
  const { userId, bookIds } = req.body;

  if (!userId || !bookIds || !Array.isArray(bookIds) || bookIds.length === 0) {
    return res.status(400).json({ error: 'Missing or invalid userId/bookIds' });
  }

  try {
    // Получаем данные о пользователе
    const userResponse = await axios.get(`http://localhost:3001/users/${userId}`);
    const user = userResponse.data;

    // Проверяем доступность книг
    const bookResponse = await axios.post('http://localhost:3002/books/availability', { bookIds });
    const books = bookResponse.data.books;

    const unavailableBooks = books.filter(book => !book.available);
    if (unavailableBooks.length > 0) {
      return res.status(400).json({ error: 'Следующие книги недоступны', unavailableBooks });
    }

    const loanDate = new Date();
    const returnDate = new Date(loanDate);
    returnDate.setDate(loanDate.getDate() + 14);

    // Вставляем запись для каждой книги
    for (const bookId of bookIds) {
      await pool.execute(
        'INSERT INTO loans (userId, bookId, loanDate, returnDate) VALUES (?, ?, ?, ?)',
        [userId, bookId, loanDate.toISOString().split('T')[0], returnDate.toISOString().split('T')[0]]
      );
    }

    res.status(201).json({
      message: 'Заказ успешно создан',
      user,
      books,
      loanDate: loanDate.toISOString().split('T')[0],
      returnDate: returnDate.toISOString().split('T')[0]
    });
  } catch (err) {
    console.error('Error in POST /loans:', err.message);
    const status = err.response ? err.response.status : 500;
    res.status(status).json({ error: err.message });
  }
});

app.get('/loans', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM loans');
    console.log('Fetched loans from DB:', rows);

    // Группируем записи по userId и loanDate для формирования заказов
    const loansMap = new Map();
    for (const row of rows) {
      const key = `${row.userId}-${row.loanDate}`; // Уникальный ключ для заказа
      if (!loansMap.has(key)) {
        loansMap.set(key, {
          loanId: row.id, // Используем id первой записи как loanId
          userId: row.userId,
          books: [],
          loanDate: row.loanDate,
          returnDate: row.returnDate
        });
      }
      loansMap.get(key).books.push({ bookId: row.bookId, title: `Book ${row.bookId}` }); // Заглушка для title
    }

    const loans = Array.from(loansMap.values());

    // Получаем данные о пользователях и книгах
    for (const loan of loans) {
      try {
        const userResponse = await axios.get(`http://localhost:3001/users/${loan.userId}`);
        loan.user = userResponse.data;
      } catch (err) {
        loan.user = { userId: loan.userId, name: 'Unknown' };
      }

      try {
        const bookResponse = await axios.post('http://localhost:3002/books/availability', {
          bookIds: loan.books.map(b => b.bookId)
        });
        const booksData = bookResponse.data.books;
        loan.books = loan.books.map(book => ({
          bookId: book.bookId,
          title: booksData.find(b => b.bookId === book.bookId)?.title || `Book ${book.bookId}`
        }));
      } catch (err) {
        console.error('Error fetching books for loan:', err.message);
      }

      delete loan.userId; // Удаляем userId, так как он теперь в loan.user
    }

    res.json(loans);
  } catch (err) {
    console.error('Error in GET /loans:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.listen(3003, '127.0.0.1', () => {
  console.log('Loan Service running on port 3003');
}); 
